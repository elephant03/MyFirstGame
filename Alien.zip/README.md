# MyFirstGame

## Current Release Version
0.0

## Current Version In Progress
0.0

## AUTHOR(S): 
Ambrose Hlustik-Smith

## Versions

### DateStarted
(YYYY/MM/DD): 2018/04/21

Version Num | Date Completed
------------|---------------
0.0| N/A


### Description
A simple alian invasion game clone- this will be the first game I am not directly following a tutorial for

### Requirments 
Python 3.X (written in 3.6) with standered python libary and [pygame](https://www.pygame.org)
